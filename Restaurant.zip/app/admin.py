from django.contrib import admin
from .models import Employee, Item

admin.site.register(Employee)
admin.site.register(Item)
# admin.site.register(Order)
